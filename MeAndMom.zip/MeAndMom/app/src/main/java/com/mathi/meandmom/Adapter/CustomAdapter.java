package com.mathi.meandmom.Adapter;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mathi.meandmom.Model.VideoDetail;
import com.mathi.meandmom.PlayerActivity;
import com.mathi.meandmom.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class CustomAdapter extends BaseAdapter {

    Activity activity;
    List<VideoDetail> videoDetailList;
    LayoutInflater inflater;

    public CustomAdapter(Activity activity, List<VideoDetail> videoDetailList) {
        this.activity = activity;
        this.videoDetailList = videoDetailList;
    }

    @Override
    public int getCount() {
        return this.videoDetailList.size();
    }

    @Override
    public Object getItem(int i) {
        return this.videoDetailList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return (long)i;
    }

    @Override
    public View getView(int i, View convertView, ViewGroup viewGroup) {

        if (inflater == null) {
            inflater = this.activity.getLayoutInflater();
        }

        if (convertView == null) {
            convertView = inflater.inflate(R.layout.custom_item, null);
        }

        final VideoDetail videoDetail = (VideoDetail) this.videoDetailList.get(i);

        ImageView imageView = (ImageView) convertView.findViewById(R.id.imageView);
        TextView textView = (TextView) convertView.findViewById(R.id.title);
        LinearLayout linearLayout = (LinearLayout) convertView.findViewById(R.id.root);


        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(activity, PlayerActivity.class);
                i.putExtra("videoId", videoDetail.getVideoId());
                activity.startActivity(i);
            }
        });


        Picasso.get().load(videoDetail.getUrl()).into(imageView);
        textView.setText(videoDetail.getTitle());

        return convertView;
    }
}
