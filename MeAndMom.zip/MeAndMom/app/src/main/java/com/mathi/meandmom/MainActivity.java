package com.mathi.meandmom;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText txtUserName;
    private EditText txtPassword;
    private Button btnLogin;
    private TextView txtLoginMessage;
    private int maxLoginCount = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtUserName = (EditText) findViewById(R.id.editTextUsername);
        txtPassword = (EditText) findViewById(R.id.editTextPassword);
        btnLogin = (Button) findViewById(R.id.btnLogin);
        txtLoginMessage = (TextView) findViewById(R.id.txtLoginMessage);

        txtLoginMessage.setText("");

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validate(txtUserName.getText().toString(), txtPassword.getText().toString());
            }
        });
    }


    private void validate(String username, String password) {
        if (username.equals("1234") && password.equals("1234")) {
            Intent intent = new Intent(MainActivity.this, VideoSuggestionActivity.class);
            startActivity(intent);
        }
        else {
            maxLoginCount--;

            txtLoginMessage.setText("No of attempts remaining : " + String.valueOf(maxLoginCount));

            if (maxLoginCount == 0) {
                btnLogin.setEnabled(false);
            }

        }
    }
}
