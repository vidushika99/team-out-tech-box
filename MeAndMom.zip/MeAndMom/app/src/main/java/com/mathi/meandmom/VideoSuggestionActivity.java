package com.mathi.meandmom;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import com.mathi.meandmom.Adapter.CustomAdapter;
import com.mathi.meandmom.Model.VideoDetail;

import java.util.ArrayList;
import java.util.List;


public class VideoSuggestionActivity extends AppCompatActivity {

    ListView listView;
    List<VideoDetail> videoDetailArrayList;
    CustomAdapter customAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_suggestion);
        listView = (ListView) findViewById(R.id.listView);
        videoDetailArrayList = new ArrayList<>();

        customAdapter = new CustomAdapter(VideoSuggestionActivity.this, videoDetailArrayList);

    }

}
