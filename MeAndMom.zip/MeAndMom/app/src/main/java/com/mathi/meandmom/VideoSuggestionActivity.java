package com.mathi.meandmom;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.mathi.meandmom.Adapter.CustomAdapter;
import com.mathi.meandmom.Model.VideoDetail;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class VideoSuggestionActivity extends AppCompatActivity {

    ListView listView;
    List<VideoDetail> videoDetailArrayList;
    CustomAdapter customAdapter;

    String API_KEY = "AIzaSyA_yOCJKvsoIdNwI--FvtgvNGbWJDSD4fQ";
    //String url = "https://www.googleapis.com/youtube/v3/activities?part=snippet,contentDetails&channelId=UCpPOf9BQPwa4K11Zjxu1ZPw&mazResults=2&key=AIzaSyA_yOCJKvsoIdNwI--FvtgvNGbWJDSD4fQ";
    String url = "https://www.googleapis.com/youtube/v3/search?part=snippet&channelid=UCpPOf9BQPwa4K11Zjxu1ZPw-2Is3LJWN4Ws&maxResults=10&key=AIzaSyA_yOCJKvsoIdNwI--FvtgvNGbWJDSD4fQ";

    /*

    https://www.googleapis.com/youtube/v3/activities?part=snippet&channelId=UCpPOf9BQPwa4K11Zjxu1ZPw&key=AIzaSyA_yOCJKvsoIdNwI--FvtgvNGbWJDSD4fQ

    https://www.googleapis.com/youtube/v3/search?part=snippet&channelid=&maxResults=10&key=AIzaSyA_yOCJKvsoIdNwI--FvtgvNGbWJDSD4fQ

    https://www.googleapis.com/youtube/v3/search?part=snippet&channelid=UCNyKpfdMfxxbTsiPKXjMazQ&maxResults=1&key=AIzaSyA_yOCJKvsoIdNwI--FvtgvNGbWJDSD4fQ

    https://www.googleapis.com/youtube/v3/search?part=snippet&channelid=UCNyKpfdMfxxbTsiPKXjMazQ&maxResults=1&key=AIzaSyA_yOCJKvsoIdNwI--FvtgvNGbWJDSD4fQ

    https://www.googleapis.com/youtube/v3/videos?id=9zX2BQFZ_BI&key=AIzaSyA_yOCJKvsoIdNwI--FvtgvNGbWJDSD4fQ&part=statistics

    https://www.googleapis.com/youtube/v3/search?part=snippet&channelid=UCpPOf9BQPwa4K11Zjxu1ZPw-2Is3LJWN4Ws&maxResults=10&key=AIzaSyA_yOCJKvsoIdNwI--FvtgvNGbWJDSD4fQ

    https://www.youtube.com/watch?v=qTyj2R-wcks&t=201s

    https://www.youtube.com/watch?v=AcUauzCn7RE
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_suggestion);
        listView = (ListView) findViewById(R.id.listView);
        videoDetailArrayList = new ArrayList<>();

        customAdapter = new CustomAdapter(VideoSuggestionActivity.this, videoDetailArrayList);
        displayListOfVideos();
    }

    public void displayListOfVideos() {

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("items");

                    for (int i = 0; i< jsonArray.length(); i++) {
                        JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                        JSONObject jsonVideoID = jsonObject1.getJSONObject("id");
                        JSONObject jsonObjectSnippet = jsonObject1.getJSONObject("snippet");
                        JSONObject jsonObjectDefault = jsonObjectSnippet.getJSONObject("thumbnails").getJSONObject("medium");

                        String videoID = jsonVideoID.getString("videoId");

                        VideoDetail vd = new VideoDetail();

                        vd.setVideoId(videoID);
                        vd.setTitle(jsonObjectSnippet.getString("title"));
                        vd.setDescription(jsonObjectSnippet.getString("description"));
                        vd.setUrl(jsonObjectDefault.getString("url"));

                        videoDetailArrayList.add(vd);
                    }

                    listView.setAdapter(customAdapter);
                    customAdapter.notifyDataSetChanged();

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        requestQueue.add(stringRequest);
    }
}
